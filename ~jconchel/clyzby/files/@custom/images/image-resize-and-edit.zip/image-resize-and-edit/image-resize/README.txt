Resize the original image to make three smaller ones.  Always start with the full-size image (basil-original.jpg) and resize the image, and constrain the proportions.  Save as new JPEG files using "80" as the quality setting.

1.  basil-800.jpg -- width of 800 px
2.  basil-400.jpg -- width of 400 px
3.  basil-200.jpg -- width of 200 px
